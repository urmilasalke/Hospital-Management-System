"""Hospital URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from clinic.views import home,about,gallery,contact,home2,appoint,evm,criticalCare,dentalScience,skincare,feedback,deluser,singleapp,withus,todayapp
from clinic.views import resume


urlpatterns = [
    path('admin/', admin.site.urls),
    path('home',home,name='home'),
    path('about/',about,name='about'),
    path('gallery/',gallery,name='gallery'),
     path('contact/',contact,name='contact'),
     path('',home2,name='home2'),
    path('appoint/',appoint,name='appoint'),
     path('skincare/',skincare,name='skincare'),
      path('dentalScience/',dentalScience,name='dentalScience'),
    path('evm/',evm,name='evm'),
     path('criticalCare/',criticalCare,name='criticalCare'),
     path('feedback/',feedback,name='feedback'),
     path('withus/',withus,name='withus'),
     path('resume/',resume,name='resume'),
     path('todayapp/',todayapp,name='todayapp'),
     path('deluser/<int:id>/',deluser,name='deluser'),
     path('singleapp/<int:id>/',singleapp,name='singleapp'),

]
